# insurance_predictor/insurance_predictor/__init__.py

from .predictor import InsurancePredictor
